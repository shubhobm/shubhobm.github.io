# EM for ABO allele frequencies, assuming no blood-typing errors.
# Counts must be named A, B, AB, O. No additional packages are needed.

abo_em <- function(counts = c(A = 135, B = 39, AB = 18, O = 108),
                   start = c(A = 1/3, B = 1/3, O = 1/3),
                   tol = 1e-10, maxit = 1000) {
  stopifnot(all(c("A", "B", "AB", "O") %in% names(counts)),
            all(c("A", "B", "O") %in% names(start)))
  counts <- counts[c("A", "B", "AB", "O")]
  p <- start[c("A", "B", "O")]
  stopifnot(all(is.finite(counts)), all(counts >= 0),
            all(counts == floor(counts)), sum(counts) > 0,
            all(is.finite(p)), all(p > 0),
            abs(sum(p) - 1) < 1e-8, tol > 0, maxit >= 1)
  p <- p / sum(p)
  n <- sum(counts)

  # Observed-data log-likelihood, omitting the multinomial constant.
  loglik <- function(p) {
    a <- unname(p["A"])
    b <- unname(p["B"])
    o <- unname(p["O"])
    probabilities <- c(A = a^2 + 2*a*o,
                       B = b^2 + 2*b*o,
                       AB = 2*a*b, O = o^2)
    used <- counts > 0   # Avoid 0 * log(0) for unobserved types.
    sum(counts[used] * log(probabilities[used]))
  }

  record <- function(iter, p, ll) {
    data.frame(iter = iter, p_A = unname(p["A"]),
               p_B = unname(p["B"]), p_O = unname(p["O"]),
               loglik = ll)
  }
  ll <- loglik(p)
  history <- record(0, p, ll)
  converged <- FALSE

  for (iter in seq_len(maxit)) {
    a <- unname(p["A"])
    b <- unname(p["B"])
    o <- unname(p["O"])

    # E-STEP: expected genotype counts given the observed phenotypes.
    # Only A and B phenotypes have ambiguous genotypes in this model.
    n_AA <- if (counts["A"] == 0) 0 else
      counts["A"] * a^2 / (a^2 + 2*a*o)
    n_AO <- counts["A"] - n_AA
    n_BB <- if (counts["B"] == 0) 0 else
      counts["B"] * b^2 / (b^2 + 2*b*o)
    n_BO <- counts["B"] - n_BB
    n_AB <- counts["AB"]
    n_OO <- counts["O"]

    # M-STEP: expected allele counts divided by the total 2*n alleles.
    p_new <- c(A = unname((2*n_AA + n_AO + n_AB) / (2*n)),
               B = unname((2*n_BB + n_BO + n_AB) / (2*n)),
               O = unname((2*n_OO + n_AO + n_BO) / (2*n)))

    ll_new <- loglik(p_new)
    if (ll_new < ll - 1e-8) stop("Log-likelihood decreased unexpectedly.")
    history <- rbind(history, record(iter, p_new, ll_new))
    change <- max(abs(p_new - p))
    p <- p_new
    ll <- ll_new
    if (change < tol) {
      converged <- TRUE
      break
    }
  }
  if (!converged) warning("Iteration limit reached.")
  list(p = p, history = history, converged = converged)
}

# Example from the slides:
# source("abo_em.R")
# fit <- abo_em(c(A = 135, B = 39, AB = 18, O = 108))
# fit$p
# fit$history
#
# Convergence plots (use the RStudio Plots pane):
# par(mfrow = c(1, 2))
# matplot(fit$history$iter, fit$history[c("p_A", "p_B", "p_O")],
#         type = "l", lty = 1, lwd = 2, col = c(1, 2, 4),
#         xlab = "Iteration", ylab = "Allele frequency")
# legend("topright", c("A", "B", "O"), col = c(1, 2, 4),
#        lty = 1, lwd = 2, bty = "n")
# plot(fit$history$iter, fit$history$loglik, type = "b", pch = 16,
#      xlab = "Iteration", ylab = "Observed log-likelihood")
# par(mfrow = c(1, 1))
