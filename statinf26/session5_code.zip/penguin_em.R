# Run once if needed: install.packages("palmerpenguins")

em_fit <- function(x, mu = c(185, 205), sigma = c(12, 12),
                   pi1 = 0.5, tol = 1e-8, maxit = 500) {
  stopifnot(length(x) > 2, all(is.finite(x)),
            length(mu) == 2, length(sigma) == 2,
            all(sigma > 0), pi1 > 0, pi1 < 1)

  # Stable E-step and observed-data log-likelihood.
  evaluate <- function(mu, sigma, pi1) {
    a <- log(pi1) + dnorm(x, mu[1], sigma[1], log = TRUE)
    b <- log1p(-pi1) + dnorm(x, mu[2], sigma[2], log = TRUE)
    m <- pmax(a, b)
    log_density <- m + log(exp(a - m) + exp(b - m))
    list(r = exp(a - log_density), ll = sum(log_density))
  }
  record <- function(iter, mu, sigma, pi1, ll) {
    data.frame(iter, mu1 = mu[1], mu2 = mu[2],
               sd1 = sigma[1], sd2 = sigma[2], pi1, loglik = ll)
  }

  current <- evaluate(mu, sigma, pi1)
  history <- record(0, mu, sigma, pi1, current$ll)
  converged <- FALSE
  for (iter in seq_len(maxit)) {
    # E-step: soft membership probabilities under current parameters.
    r <- current$r
    n1 <- sum(r)
    n2 <- sum(1 - r)
    if (min(n1, n2) < 1e-10) stop("Empty component: change initialization.")

    # M-step: variances use the NEW means and denominators n1, n2.
    mu <- c(sum(r * x) / n1, sum((1 - r) * x) / n2)
    sigma <- sqrt(c(sum(r * (x - mu[1])^2) / n1,
                    sum((1 - r) * (x - mu[2])^2) / n2))
    if (any(sigma < 1e-8)) stop("Variance collapse: change initialization.")
    pi1 <- n1 / length(x)

    updated <- evaluate(mu, sigma, pi1)
    gain <- updated$ll - current$ll
    if (gain < -1e-7) stop("Log-likelihood decreased unexpectedly.")
    history <- rbind(history, record(iter, mu, sigma, pi1, updated$ll))
    done <- abs(gain) <= tol * (1 + abs(current$ll))
    current <- updated
    if (done) {
      converged <- TRUE
      break
    }
  }
  if (!converged) warning("Iteration limit reached.")
  list(history = history, probability1 = current$r, converged = converged)
}

show_em <- function(x, fit, pause = 0.25, step = FALSE) {
  # Prefer the RStudio Plots pane, even if an external device is active.
  if (Sys.getenv("RSTUDIO") == "1") {
    devices <- grDevices::dev.list()
    studio <- devices[names(devices) == "RStudioGD"]
    if (length(studio)) {
      grDevices::dev.set(studio[1])
    } else {
      grDevices::dev.new(device = "RStudioGD", noRStudioGD = FALSE)
    }
  }
  h <- fit$history
  grid <- seq(min(x) - 8, max(x) + 8, length.out = 500)
  bins <- hist(x, breaks = 20, plot = FALSE)
  ymax <- max(bins$density, vapply(seq_len(nrow(h)), function(j) {
    p <- h[j, ]
    max(p$pi1 * dnorm(grid, p$mu1, p$sd1) +
          (1 - p$pi1) * dnorm(grid, p$mu2, p$sd2))
  }, numeric(1))) * 1.1
  cols <- c("#0072B2", "#D55E00")
  old <- par(no.readonly = TRUE)
  on.exit(par(old))
  par(mfrow = c(2, 2), mar = c(4, 4, 3, 1))

  for (j in seq_len(nrow(h))) {
    p <- h[j, ]
    k <- seq_len(j)
    f1 <- p$pi1 * dnorm(grid, p$mu1, p$sd1)
    f2 <- (1 - p$pi1) * dnorm(grid, p$mu2, p$sd2)

    hist(x, breaks = bins$breaks, probability = TRUE,
         col = "grey90", border = "white", ylim = c(0, ymax),
         xlim = range(grid), xlab = "Flipper length (mm)",
         main = paste("EM iteration", p$iter))
    lines(grid, f1, col = cols[1], lwd = 2)
    lines(grid, f2, col = cols[2], lwd = 2)
    lines(grid, f1 + f2, lwd = 2)
    legend("topright", c("Weighted component 1", "Weighted component 2", "Mixture"),
           col = c(cols, "black"), lty = 1, bty = "n", cex = 0.7)

    # Posterior probabilities at this iteration (not hard assignments).
    a <- log(p$pi1) + dnorm(x, p$mu1, p$sd1, log = TRUE)
    b <- log1p(-p$pi1) + dnorm(x, p$mu2, p$sd2, log = TRUE)
    plot(x, plogis(a - b), pch = 16, cex = 0.6, col = cols[1],
         ylim = c(0, 1), xlab = "Flipper length (mm)",
         ylab = "P(component 1 | flipper length)",
         main = sprintf("Mixing proportion = %.3f", p$pi1))

    plot(h$iter[k], h$loglik[k], type = "o", pch = 16, cex = 0.4,
         xlim = range(h$iter), ylim = range(h$loglik),
         xlab = "Iteration", ylab = "Observed log-likelihood",
         main = "Likelihood convergence")

    matplot(h$iter[k], h[k, c("mu1", "mu2")], type = "l",
            lty = 1, lwd = 2, col = cols, xlim = range(h$iter),
            ylim = range(h$mu1, h$mu2), xlab = "Iteration",
            ylab = "Mean flipper length (mm)", main = "Mean estimates")
    points(rep(p$iter, 2), c(p$mu1, p$mu2), col = cols, pch = 16)
    if (step && interactive()) readline("Press Enter for the next iteration: ")
    else if (pause > 0) Sys.sleep(pause)
  }
  invisible(fit)
}

# Use species ONLY to select the two-species dataset, never in the EM fit.
if (sys.nframe() == 0L) {
  if (!requireNamespace("palmerpenguins", quietly = TRUE)) {
    stop('First run install.packages("palmerpenguins").')
  }
  penguins <- palmerpenguins::penguins
  keep <- penguins$species %in% c("Adelie", "Gentoo") &
    !is.na(penguins$flipper_length_mm)
  x <- penguins$flipper_length_mm[keep]
  fit <- em_fit(x)
  print(tail(fit$history, 1), row.names = FALSE)
  show_em(x, fit, pause = 0.25) # Use step = TRUE to advance manually.
}
