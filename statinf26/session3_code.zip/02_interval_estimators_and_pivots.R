# Statistical Inference: Interval Estimators and Pivotal Quantities
# ----------------------------------------------------------------
# Base R only. No testing language is needed.
#
# An interval estimator is a pair of statistics [L(X), U(X)].
# Its coverage function is P_theta{L(X) <= theta <= U(X)}.
# A pivotal quantity is a function Q(X, theta) whose distribution does not
# depend on theta (or on any other unknown parameter).

set.seed(20260917)

B <- 20000
confidence_level <- 0.95
alpha <- 1 - confidence_level

# -----------------------------------------------------------------------------
# Example 1: Normal mean, known sigma
# -----------------------------------------------------------------------------

sigma <- 4
n <- 25
mu_values <- c(-5, 0, 8)
z_star <- qnorm(1 - alpha / 2)

# Pivot: Z = (Xbar - mu) / (sigma/sqrt(n)) ~ N(0,1).
normal_known <- do.call(rbind, lapply(mu_values, function(mu) {
  xbar <- rowMeans(matrix(rnorm(B * n, mean = mu, sd = sigma), nrow = B))
  pivot <- (xbar - mu) / (sigma / sqrt(n))
  lower <- xbar - z_star * sigma / sqrt(n)
  upper <- xbar + z_star * sigma / sqrt(n)
  data.frame(mu = mu, xbar = xbar, pivot = pivot,
             lower = lower, upper = upper,
             covers = lower <= mu & mu <= upper)
}))

known_summary <- do.call(rbind, lapply(split(normal_known, normal_known$mu), function(d) {
  data.frame(
    mu = d$mu[1],
    pivot_mean = mean(d$pivot),
    pivot_sd = sd(d$pivot),
    empirical_coverage = mean(d$covers),
    interval_width = mean(d$upper - d$lower)
  )
}))

cat("\nNormal mean with known sigma\n")
print(known_summary, digits = 4, row.names = FALSE)

# The pivot distributions align even though the unknown means differ.
par(mfrow = c(1, 2), mar = c(4.5, 4.5, 3, 1))
hist(normal_known$pivot[normal_known$mu == mu_values[1]], probability = TRUE,
     breaks = 50, col = rgb(0.1, 0.4, 0.7, 0.35), border = NA,
     xlim = c(-4, 4), main = "Pivot is parameter-free",
     xlab = expression((bar(X) - mu)/(sigma/sqrt(n))))
for (j in 2:length(mu_values)) {
  lines(density(normal_known$pivot[normal_known$mu == mu_values[j]]),
        col = c("#C0392B", "#2E8B57")[j - 1], lwd = 2)
}
curve(dnorm(x), add = TRUE, lwd = 2, lty = 2)
legend("topright", legend = c(paste("mu =", mu_values), "N(0,1)"),
       col = c(rgb(0.1, 0.4, 0.7), "#C0392B", "#2E8B57", "black"),
       lty = c(1, 1, 1, 2), lwd = 2, bty = "n", cex = 0.8)

# Display 30 realized intervals. Some miss; most cover.
d0 <- normal_known[normal_known$mu == 0, ][1:30, ]
plot(d0$xbar, 1:30, xlim = range(c(d0$lower, d0$upper)),
     pch = 16, xlab = "Interval for mu", ylab = "Simulation index",
     main = "Repeated 95% interval estimates")
segments(d0$lower, 1:30, d0$upper, 1:30,
         col = ifelse(d0$covers, "#1B6CA8", "#C0392B"), lwd = 2)
abline(v = 0, lty = 2, lwd = 2)
par(mfrow = c(1, 1))

# -----------------------------------------------------------------------------
# Example 2: Normal mean, unknown sigma
# -----------------------------------------------------------------------------

# Pivot: T = (Xbar - mu)/(S/sqrt(n)) ~ t_{n-1}.
mu <- 3
sigma <- 5
n <- 12
t_star <- qt(1 - alpha / 2, df = n - 1)

unknown_normal <- replicate(B, {
  x <- rnorm(n, mean = mu, sd = sigma)
  xbar <- mean(x)
  s <- sd(x)
  lower <- xbar - t_star * s / sqrt(n)
  upper <- xbar + t_star * s / sqrt(n)
  c(pivot = (xbar - mu) / (s / sqrt(n)), lower = lower, upper = upper,
    covers = lower <= mu && mu <= upper)
})
unknown_normal <- t(unknown_normal)

cat("\nNormal mean with unknown sigma\n")
cat("Pivot mean:", mean(unknown_normal[, "pivot"]), "\n")
cat("Pivot SD:", sd(unknown_normal[, "pivot"]), "\n")
cat("Empirical coverage:", mean(unknown_normal[, "covers"]), "\n")
cat("Average width:", mean(unknown_normal[, "upper"] - unknown_normal[, "lower"]), "\n")

hist(unknown_normal[, "pivot"], probability = TRUE, breaks = 60,
     col = "#DCEAF7", border = "white", main = "Student t pivot",
     xlab = expression((bar(X) - mu)/(S/sqrt(n))), xlim = c(-5, 5))
curve(dt(x, df = n - 1), add = TRUE, col = "#C0392B", lwd = 2)

# -----------------------------------------------------------------------------
# Example 3: Uniform(0, theta), a non-normal pivot
# -----------------------------------------------------------------------------

# If M = max(X_1,...,X_n), then Q = M/theta has CDF q^n on [0,1].
# Since P(alpha^(1/n) <= M/theta <= 1) = 1-alpha,
# [M, M/alpha^(1/n)] is an exact interval estimator for theta.

theta <- 10
n <- 8
u <- matrix(runif(B * n, min = 0, max = theta), nrow = B)
m <- apply(u, 1, max)
q_pivot <- m / theta
lower <- m
upper <- m / alpha^(1 / n)
covers <- lower <= theta & theta <= upper

cat("\nUniform(0, theta) maximum pivot\n")
cat("Empirical coverage:", mean(covers), "\n")
cat("Exact target coverage:", confidence_level, "\n")
cat("Average interval width:", mean(upper - lower), "\n")

hist(q_pivot, probability = TRUE, breaks = 50, col = "#E8F5E9",
     border = "white", xlim = c(0, 1),
     main = expression("Pivot " * M/theta), xlab = "q")
curve(n * x^(n - 1), from = 0, to = 1, add = TRUE,
      col = "#2E8B57", lwd = 2)

# -----------------------------------------------------------------------------
# Example 4: Coverage and width as n changes
# -----------------------------------------------------------------------------

mu <- 0
sigma <- 4
n_grid <- c(5, 10, 20, 50, 100, 250)

coverage_by_n <- do.call(rbind, lapply(n_grid, function(n) {
  xbar <- rowMeans(matrix(rnorm(B * n, mu, sigma), nrow = B))
  half_width <- z_star * sigma / sqrt(n)
  lower <- xbar - half_width
  upper <- xbar + half_width
  data.frame(n = n,
             coverage = mean(lower <= mu & mu <= upper),
             width = 2 * half_width)
}))

cat("\nCoverage and width by sample size\n")
print(coverage_by_n, digits = 4, row.names = FALSE)

par(mfrow = c(1, 2), mar = c(4.5, 4.5, 3, 1))
plot(coverage_by_n$n, coverage_by_n$coverage, type = "b", pch = 16,
     ylim = c(0.90, 1), xlab = "n", ylab = "Empirical coverage",
     main = "Coverage stays near 0.95")
abline(h = confidence_level, lty = 2)
plot(coverage_by_n$n, coverage_by_n$width, type = "b", pch = 16,
     xlab = "n", ylab = "Interval width",
     main = "Precision improves with n")
par(mfrow = c(1, 1))

# Classroom prompts
# 1. Why do the three Z-pivot distributions align despite different mu values?
# 2. Which object is random before sampling: the parameter or the interval?
# 3. Why does interval width shrink while coverage stays approximately fixed?
# 4. Why can M/theta be a pivot even though M itself depends on theta?

