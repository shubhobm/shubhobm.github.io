# Statistical Inference: Unbiasedness and Consistency
# --------------------------------------------------
# Base R only. Run the entire file, or execute one section at a time.
#
# Learning goals
# 1. Unbiasedness concerns E_theta[T_n] at a fixed sample size n.
# 2. Consistency concerns what happens to T_n as n grows.
# 3. An estimator can be unbiased but inconsistent, or biased but consistent.

set.seed(20260917)

# True parameter and Monte Carlo settings
theta <- 5
B <- 10000
n_grid <- c(2, 5, 10, 20, 50, 100, 250, 500)
epsilon <- 0.5

# We use X_i ~ Exponential(rate = 1/theta), so E[X_i] = theta.
# Three estimators of theta:
#   T1 = sample mean: unbiased and consistent
#   T2 = n/(n+1) * sample mean: biased for finite n, but consistent
#   T3 = X_1: unbiased, but not consistent because it never uses more data

simulate_estimators <- function(n, B, theta) {
  x <- matrix(rexp(B * n, rate = 1 / theta), nrow = B, ncol = n)
  x_bar <- rowMeans(x)

  data.frame(
    n = n,
    estimator = rep(c("sample mean", "shrunk sample mean", "first observation"),
                    each = B),
    estimate = c(x_bar, (n / (n + 1)) * x_bar, x[, 1])
  )
}

sim_list <- lapply(n_grid, simulate_estimators, B = B, theta = theta)
sim <- do.call(rbind, sim_list)

# Monte Carlo estimates of expectation, bias, variance, MSE, and concentration.
summarize_one <- function(d) {
  est <- d$estimate
  c(
    mean = mean(est),
    bias = mean(est) - theta,
    variance = var(est),
    mse = mean((est - theta)^2),
    prob_error_gt_epsilon = mean(abs(est - theta) > epsilon)
  )
}

groups <- split(sim, list(sim$n, sim$estimator), drop = TRUE)
summary_matrix <- t(vapply(groups, summarize_one, numeric(5)))
group_labels <- do.call(rbind, strsplit(rownames(summary_matrix), "\\."))

results <- data.frame(
  n = as.integer(group_labels[, 1]),
  estimator = group_labels[, 2],
  summary_matrix,
  row.names = NULL
)
results <- results[order(results$estimator, results$n), ]

cat("\nMonte Carlo summary\n")
print(results, digits = 4)

# Exact benchmarks for classroom comparison:
# Sample mean:
#   E[T1] = theta, Var(T1) = theta^2/n.
# Shrunk sample mean:
#   E[T2] = n*theta/(n+1), Bias(T2) = -theta/(n+1).
# First observation:
#   E[T3] = theta, Var(T3) = theta^2 for every n.

exact_summary <- data.frame(
  n = rep(n_grid, 3),
  estimator = rep(c("sample mean", "shrunk sample mean", "first observation"),
                  each = length(n_grid))
)
exact_summary$exact_bias <- with(exact_summary,
  ifelse(estimator == "sample mean", 0,
  ifelse(estimator == "shrunk sample mean", -theta / (n + 1), 0)))
exact_summary$exact_variance <- with(exact_summary,
  ifelse(estimator == "sample mean", theta^2 / n,
  ifelse(estimator == "shrunk sample mean",
         (n / (n + 1))^2 * theta^2 / n,
         theta^2)))

cat("\nExact bias and variance\n")
print(exact_summary, digits = 4)

# Plot 1: estimated expectation as n grows.
estimators <- unique(results$estimator)
cols <- c("#1B6CA8", "#C0392B", "#2E8B57")
symbols <- c(16, 17, 15)

par(mfrow = c(1, 2), mar = c(4.5, 4.5, 3, 1))
plot(range(n_grid), range(results$mean, theta), type = "n", log = "x",
     xlab = "Sample size n (log scale)", ylab = "Monte Carlo mean of estimator",
     main = "Unbiasedness is about the center")
abline(h = theta, lty = 2, lwd = 2)
for (j in seq_along(estimators)) {
  d <- results[results$estimator == estimators[j], ]
  lines(d$n, d$mean, type = "b", pch = symbols[j], col = cols[j], lwd = 2)
}
legend("bottomright", legend = estimators, col = cols, pch = symbols,
       lty = 1, bty = "n", cex = 0.85)

# Plot 2: probability of an error larger than epsilon.
plot(range(n_grid), c(0, 1), type = "n", log = "x",
     xlab = "Sample size n (log scale)",
     ylab = paste0("P(|T_n - theta| > ", epsilon, ")"),
     main = "Consistency is concentration")
for (j in seq_along(estimators)) {
  d <- results[results$estimator == estimators[j], ]
  lines(d$n, d$prob_error_gt_epsilon, type = "b", pch = symbols[j],
        col = cols[j], lwd = 2)
}
legend("topright", legend = estimators, col = cols, pch = symbols,
       lty = 1, bty = "n", cex = 0.85)
par(mfrow = c(1, 1))

# Classroom prompts
# 1. Why does the first observation remain unbiased as n increases?
# 2. Why does unbiasedness fail to guarantee consistency?
# 3. At small n, can the biased MLE of variance have smaller MSE?
# 4. Which quantity in the consistency plot should approach zero?

