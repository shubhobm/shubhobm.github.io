# EXERCISE 1: Construct an LRT and recover the two-sided Z test (15 minutes)
# Base R only. Run this script independently, or source it in RStudio.
# X = weekly minutes a user watches the platform's five most-watched shows
# (ranked by total platform viewing in the previous week).
# Normality and known sigma are simplified teaching assumptions.
# H0: mu = 100 versus H1: mu != 100.

set.seed(101)
n <- 30
mu0 <- 100
mu_true <- 108                  # Try 100, 104, 108.
sigma <- 20                    # Known population SD, not estimated from x.
alpha <- 0.05
x <- rnorm(n, mean = mu_true, sd = sigma)

# Work with log-likelihoods to avoid underflow from multiplying densities.
ell <- function(mu) sum(dnorm(x, mean = mu, sd = sigma, log = TRUE))
mu_hat <- mean(x)
se <- sigma / sqrt(n)
search_interval <- range(c(mu0, mu_hat)) + c(-6, 6) * se
fit <- optimize(ell, interval = search_interval, maximum = TRUE)

ell_null <- ell(mu0)
ell_full <- ell(mu_hat)
W <- 2 * (ell_full - ell_null)
Lambda <- exp(ell_null - ell_full)
Z <- (mu_hat - mu0) / se
W_formula <- n * (mu_hat - mu0)^2 / sigma^2
p_lrt <- pchisq(W, df = 1, lower.tail = FALSE)
p_z <- 2 * pnorm(-abs(Z))
critical <- qchisq(1 - alpha, df = 1)

stopifnot(abs(fit$maximum - mu_hat) < 1e-4,
          abs(W - W_formula) < 1e-8,
          abs(p_lrt - p_z) < 1e-10)
print(data.frame(n, mu0, mu_hat, numerical_MLE = fit$maximum,
                 Lambda, W, Z_squared = Z^2, p_lrt, p_z,
                 reject = W > critical), digits = 5)

# Panel 1: vertical gap between the restricted and unrestricted maxima.
# Panel 2: exact null distribution, with rejection region shaded.
local({
  old <- par(mfrow = c(1, 2), mar = c(4.5, 4.5, 3, 1))
  on.exit(par(old))
  grid <- seq(search_interval[1], search_interval[2], length.out = 500)
  plot(grid, vapply(grid, ell, numeric(1)), type = 'l', lwd = 2,
       xlab = expression(mu), ylab = 'Log-likelihood',
       main = 'Fit lost under the null')
  points(c(mu0, mu_hat), c(ell_null, ell_full), pch = c(17, 19),
         col = c('firebrick', 'steelblue'))
  segments(mu0, ell_null, mu0, ell_full, col = 'firebrick', lwd = 3)
  abline(h = ell_full, lty = 3)
  legend('bottomleft', c('Null mean', 'Unrestricted MLE', 'Gap = W / 2'),
         col = c('firebrick', 'steelblue', 'firebrick'),
         pch = c(17, 19, NA), lty = c(NA, NA, 1), bty = 'n', cex = .85)
  xmax <- max(10, W * 1.15)
  curve(dchisq(x, df = 1), from = .02, to = xmax, n = 600,
        xlim = c(0, xmax), ylim = c(0, .8), lwd = 2,
        xlab = 'W', ylab = 'Density', main = 'Exact null distribution')
  tail_x <- seq(critical, xmax, length.out = 400)
  polygon(c(critical, tail_x, xmax),
          c(0, dchisq(tail_x, 1), 0), col = 'mistyrose', border = NA)
  abline(v = critical, col = 'firebrick', lty = 2, lwd = 2)
  abline(v = W, col = 'steelblue', lwd = 2)
  legend('topright', c('5% critical value', 'Observed W'),
         col = c('firebrick', 'steelblue'), lty = c(2, 1), bty = 'n')
})
cat('\nHere W = Z^2 has an EXACT chi-square(1) null distribution.\n')
# Discuss: Why is W nonnegative? Why does a large W reject the null?
# Why do departures on either side of mu0 lead to rejection?
# Change mu_true and rerun: one simulated decision is not a power estimate.
