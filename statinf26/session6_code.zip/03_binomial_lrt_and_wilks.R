# EXERCISE 3: Exact calibration versus Wilks' approximation (15 minutes)
# Base R only; self-contained.
# X_i = 1 if user i watches at least one of the platform's five most-watched
# shows (ranked by platform viewing in the previous week); otherwise 0.
# X_i iid Bernoulli(p). H0: p = p0 versus H1: p != p0.
# W = 2*[ell(p_hat)-ell(p0)], p_hat = S/n, S = sum(X_i).
# The binomial coefficient cancels in this likelihood ratio.

set.seed(303)
alpha <- 0.05
B <- 10000
sample_sizes <- c(10, 30, 100)
null_probs <- c(0.5, 0.05)
critical <- qchisq(1 - alpha, df = 1)

lrt_stat <- function(s, n, p0) {
  stopifnot(length(n) == 1, n > 0, n == floor(n),
            length(p0) == 1, p0 > 0, p0 < 1,
            all(s >= 0 & s <= n & s == floor(s)))
  phat <- s / n
  # dbinom handles s=0 and s=n without expressions like 0*log(0).
  pmax(0, 2 * (dbinom(s, n, phat, log = TRUE) -
                dbinom(s, n, p0, log = TRUE)))
}

# Exact p-value: null probability of outcomes at least as extreme in W.
# Include ties; tolerance protects comparisons against rounding errors.
exact_lr_pvalue <- function(s_obs, n, p0) {
  support <- 0:n
  w_all <- lrt_stat(support, n, p0)
  w_obs <- lrt_stat(s_obs, n, p0)
  sum(dbinom(support, n, p0) * (w_all >= w_obs - 1e-10))
}

settings <- expand.grid(n = sample_sizes, p0 = null_probs)
summary_table <- local({
  old <- par(mfrow = c(2, 3), mar = c(4, 4, 3, 1), oma = c(0, 0, 1, 0))
  on.exit(par(old))
  output <- vector('list', nrow(settings))
  for (i in seq_len(nrow(settings))) {
    n_i <- settings$n[i]
    p0_i <- settings$p0[i]
    support <- 0:n_i
    mass <- dbinom(support, n_i, p0_i)
    w_all <- lrt_stat(support, n_i, p0_i)
    s_sim <- rbinom(B, n_i, p0_i)
    w_sim <- lrt_stat(s_sim, n_i, p0_i)
    p_exact <- vapply(support, exact_lr_pvalue, numeric(1),
                      n = n_i, p0 = p0_i)
    size_wilks <- sum(mass * (w_all > critical))
    size_exact <- sum(mass * (p_exact <= alpha + 1e-12))
    size_sim <- mean(w_sim > critical)
    output[[i]] <- data.frame(n = n_i, p0 = p0_i,
      wilks_size_exact_enumeration = size_wilks,
      wilks_size_simulation = size_sim,
      simulation_mcse = sqrt(size_sim * (1 - size_sim) / B),
      exact_LR_test_size = size_exact)
    stopifnot(size_exact <= alpha + 1e-10,
              all(is.finite(w_all)), all(p_exact >= 0 & p_exact <= 1 + 1e-12))
    # Plot to the 99.5th percentile or 10, whichever is larger.
    xmax <- max(10, as.numeric(quantile(w_sim, .995)))
    plot(ecdf(w_sim), xlim = c(0, xmax), ylim = c(0, 1),
         verticals = TRUE, do.points = FALSE, lwd = 2,
         xlab = 'W', ylab = 'Cumulative probability',
         main = paste0('n = ', n_i, ', p0 = ', p0_i))
    curve(pchisq(x, df = 1), from = 0, to = xmax, add = TRUE,
          col = 'firebrick', lwd = 2, lty = 2)
    abline(v = critical, col = 'grey50', lty = 3)
    legend('bottomright', c('Simulated null CDF', 'Chi-square(1)'),
           col = c('black', 'firebrick'), lty = c(1, 2), bty = 'n', cex = .7)
  }
  do.call(rbind, output)
})
cat('Actual size of the nominal 5% tests:\n')
print(summary_table, row.names = FALSE, digits = 4)

# One observed sample: compare asymptotic and exact LR-ordered p-values.
n_obs <- 30
p0_obs <- 0.05
s_obs <- 4
w_obs <- lrt_stat(s_obs, n_obs, p0_obs)
p_wilks <- pchisq(w_obs, df = 1, lower.tail = FALSE)
p_exact <- exact_lr_pvalue(s_obs, n_obs, p0_obs)
cat('\nObserved sample example:\n')
print(data.frame(n = n_obs, successes = s_obs, p0 = p0_obs,
                 phat = s_obs / n_obs, W = w_obs,
                 asymptotic_p = p_wilks, exact_LR_p = p_exact,
                 reject_Wilks = p_wilks < alpha,
                 reject_exact = p_exact <= alpha))
cat('\nWilks gives an asymptotic approximation, not a finite-sample guarantee.\n',
    'For fixed interior p0, convergence occurs as n grows, but need not be monotone.\n',
    'Rare events and discreteness can matter even when n looks moderately large.\n',
    'A nonrandomised exact test controls size at or below alpha, often strictly below.\n')
# Discuss: Compare p0=.5 and .05 at the same n. What changes?
# Extend sample_sizes to c(30, 100, 1000) and rerun.
# IMPORTANT: binom.test() uses probability ordering for its two-sided p-value,
# not generally LR ordering; do not expect it to match exact_lr_pvalue().
# p0 = 0 or 1 is outside this exercise and the regular interior Wilks setting.
