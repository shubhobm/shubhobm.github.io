# EXERCISE 2: Size and power of the normal-mean LRT (10-15 minutes)
# Base R only; self-contained. Same simplified Netflix minutes model.
# H0: mu = 100; sigma = 20 is known. W = n*(mean(X)-mu0)^2/sigma^2.

set.seed(202)
mu0 <- 100
sigma <- 20
alpha <- 0.05
B <- 5000
sample_sizes <- c(10, 30, 100)
true_means <- seq(90, 110, by = 2)
critical <- qchisq(1 - alpha, df = 1)
zcrit <- qnorm(1 - alpha / 2)
results <- expand.grid(mu = true_means, n = sample_sizes)
results$empirical <- results$theoretical <- results$mcse <- NA_real_

for (i in seq_len(nrow(results))) {
  n_i <- results$n[i]
  mu_i <- results$mu[i]
  # Each column is a new independent sample of n_i users.
  samples <- matrix(rnorm(n_i * B, mu_i, sigma), nrow = n_i)
  means <- colMeans(samples)
  W <- n_i * (means - mu0)^2 / sigma^2
  power_hat <- mean(W > critical)
  results$empirical[i] <- power_hat
  results$mcse[i] <- sqrt(power_hat * (1 - power_hat) / B)
  # Under mu_i, Z ~ N(delta, 1). Reject when |Z| > zcrit.
  delta <- sqrt(n_i) * (mu_i - mu0) / sigma
  results$theoretical[i] <- pnorm(-zcrit, mean = delta) +
    pnorm(zcrit, mean = delta, lower.tail = FALSE)
}

cat('Empirical size (rows where the null is true):\n')
print(subset(results, mu == mu0), row.names = FALSE, digits = 4)
cat('\nSize and power over all settings:\n')
print(results, row.names = FALSE, digits = 4)

local({
  old <- par(mar = c(4.5, 4.5, 3, 1))
  on.exit(par(old))
  colors <- c('steelblue', 'darkorange', 'darkgreen')
  plot(range(true_means), c(0, 1), type = 'n',
       xlab = expression('True mean ' * mu), ylab = 'Rejection probability',
       main = 'LRT size and power')
  abline(h = alpha, lty = 3, col = 'grey40')
  abline(v = mu0, lty = 3, col = 'grey40')
  for (j in seq_along(sample_sizes)) {
    r <- subset(results, n == sample_sizes[j])
    lines(r$mu, r$theoretical, col = colors[j], lwd = 2)
    points(r$mu, r$empirical, col = colors[j], pch = 19)
  }
  legend('topleft', paste('n =', sample_sizes), col = colors,
         lty = 1, pch = 19, lwd = 2, bty = 'n')
  legend('topright', c('Line: exact power', 'Points: simulation'),
         lty = c(1, NA), pch = c(NA, 19), bty = 'n', cex = .85)
})
cat('\nAt mu = 100, size is 0.05 for every n. Simulation adds sampling noise.\n',
    'Away from the null, larger samples increase power.\n',
    'The exact power curve is symmetric around 100; simulated points need not be.\n')
# Discuss: Does a larger n reduce Type I error at a fixed significance level?
# Try B = 500 and B = 20000. Which uncertainty changes?
# Try alpha = 0.01. What happens to size and power?
